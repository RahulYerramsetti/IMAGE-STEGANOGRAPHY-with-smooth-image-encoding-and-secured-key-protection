package steganography;

public class bool {
	
	 public static void main(String[] args) {
	        int bitmask = 2;
	        int val = 3;
	        // prints "2"
	        char st='h';
	        System.out.println(val & bitmask);
	        System.out.printf("%c",st);
	    }
}




